%%
    %mainConfig will start the particle filter from the values that are
    %included in the file. It will run the particle filter and if
    %record_movie_flag=1 it will save a movie of the particle filter run.
%%
clear all, close all;


rng(4);
%choose if the motion model or/and the color measurement should be active
motion_model_flag = 1;
use_color_association_flag =1;

%numbers of circles that the hough transform should look for
nCircles = 3;

verbose = 3;

%Set to 1 if the result should be recorded as a movie
record_movie_flag = 0;
movieName = 'movie5trackYellowMotionColor'                  

%Choose video 1,2,3 or 4 and the color to track. Uncomment one of the
%following lines:
movieMakeArray = [
                  %{1, 'red'}];
                  %{1, 'blue'}];
                  %{1, 'white'}];
                  %{2, 'yellow'}];
                  %{2, 'white'}];
                  %{3, 'black'}];
                  {4, 'yellow'}];


for i = 1:size(movieMakeArray,1)              
    
    currentConfig = movieMakeArray(i,:);
    
    video = cell2mat(currentConfig(1));
    color_to_track = cell2mat(currentConfig(2));
    
    switch(video) 

        case 1
            radii_thresholds = [9,20]; 
            video_file = 'billiardblack.mp4';

            switch(color_to_track)
                case 'red'
                    threshold_color = [255; 0; 0];
                    sigma_rgb = 80;
                case 'blue'
                    threshold_color = [0; 0; 255];
                    sigma_rgb = 75;
                case 'white'
                    threshold_color = [255; 255; 255];
                    sigma_rgb = 70;
            end

         case 2

            radii_thresholds = [30,40]; 
            binary_threshold = 150;
            video_file = 'billiard3.mp4';
            
            switch(color_to_track)
                case 'yellow'
                     threshold_color = [239; 212; 40];
                     sigma_rgb = 100; %rgb tolerance

                case 'white'
                     threshold_color = [240; 240; 240];
                     sigma_rgb = 100; %rgb tolerance
            end


        case 3
            level = 'bright';
            hough_on = 1;
            radii_thresholds = [30,50]; 
            binary_threshold = 150;
            video_file = 'billiard4.mp4';

            switch(color_to_track)
                case 'black'
                     threshold_color = [0; 0; 0];
                     sigma_rgb = 50; %rgb tolerance
            end

        case 4
            level = 'bright';
            hough_on = 1;
            radii_thresholds = [10,15];
            video_file = 'billiard2.mp4';

            switch(color_to_track)               
                case 'yellow'
                     threshold_color = [239; 212; 40];
                     sigma_rgb = 100; %rgb tolerance
            end


    end

    nParticles = 1000;

    sigma_xy = 45; % process noise in x,y.
    sigma_xy_for_hough = 20; %measurement noise
    sigma_vec = 5;%process noise in velocity

    R= [sigma_xy,0,0,0;0,sigma_xy,0,0;0,0,sigma_vec,0;0,0,0,sigma_vec].^2;

    movie = runTracking(video_file, nParticles, R, sigma_xy_for_hough, threshold_color, sigma_rgb, radii_thresholds, nCircles, motion_model_flag, verbose, record_movie_flag, use_color_association_flag);
    
    if record_movie_flag
        v = VideoWriter(sprintf('%s%d.avi',movieName,i),'Motion JPEG AVI');
        open(v);
        writeVideo(v,movie);
        close(v);
    end
   
end

