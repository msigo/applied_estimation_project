function updated_particles = predict_particles(particles,old_particles,R, particle_mean, old_particle_mean,motion_model)
% predict_particles will update the particles according to the motion model, 
% and after that do a diffusion step, where that particle cloud is spread out. 
% It retursn the updated particles as a vector.

    k_motion = 0.2;
    N = size(particles, 2);
    
    
   
    if motion_model
        %motion = k_motion(particle-old_particle); 
        %motion = k_motion*(particle_mean-particles);
        motion = repmat(k_motion*(particle_mean-old_particle_mean),1,N);
    else
        motion = 0;
    end
    
    
    updated_particles =  motion + particles;
   
    diff=sqrt(diag(R)).*randn(4,N);
    updated_particles = updated_particles + diff;
end 